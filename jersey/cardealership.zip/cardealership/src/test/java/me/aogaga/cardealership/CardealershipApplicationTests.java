package me.aogaga.cardealership;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardealershipApplicationTests {

	@Test
	void contextLoads() {
	}

}
